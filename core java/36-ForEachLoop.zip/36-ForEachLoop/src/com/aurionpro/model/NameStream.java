package com.aurionpro.model;

public class NameStream {
	public static void printName(String name) {
        System.out.println(name);
    }


}
