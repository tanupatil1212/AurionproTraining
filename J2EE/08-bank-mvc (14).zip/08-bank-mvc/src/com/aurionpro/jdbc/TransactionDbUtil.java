package com.aurionpro.jdbc;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

public class TransactionDbUtil {
	private static DataSource dataSource;

	public TransactionDbUtil(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}
	
	public static void deposit(int accountNo, BigDecimal amount) {
	    Connection conn = null;
	    PreparedStatement pstmt = null;

	    try {
	        conn = dataSource.getConnection();
	        conn.setAutoCommit(false); // Start a transaction

	        // Create a SQL query to update the account balance by depositing the specified amount
	        String sql = "UPDATE accounts SET amount = amount + ? WHERE accountno = ?";

	        pstmt = conn.prepareStatement(sql);
	        pstmt.setBigDecimal(1, amount);
	        pstmt.setInt(2, accountNo);

	        // Execute the update query
	        pstmt.executeUpdate();

	        // Commit the transaction
	        conn.commit();
	    } catch (SQLException e) {
	        // Handle exceptions, for example, by rolling back the transaction
	        try {
	            if (conn != null) {
	                conn.rollback();
	            }
	        } catch (SQLException rollbackException) {
	            rollbackException.printStackTrace();
	        }
	        e.printStackTrace();
	    } finally {
	        // Close resources and set auto-commit to true
	        try {
	            if (pstmt != null) {
	                pstmt.close();
	            }
	            if (conn != null) {
	                conn.setAutoCommit(true); // Set auto-commit back to true
	                conn.close();
	            }
	        } catch (SQLException closeException) {
	            closeException.printStackTrace();
	        }
	    }
	}


    public static void transfer(int fromAccountNo, int toAccountNo, BigDecimal amount) {
        // Implement transfer logic to transfer money from one account to another
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = dataSource.getConnection();

            // Create SQL queries to update the account balances for both accounts
            String debitSql = "UPDATE accounts SET balance = balance - ? WHERE accountno = ?";
            String creditSql = "UPDATE accounts SET balance = balance + ? WHERE accountno = ?";

            // Start a transaction
            conn.setAutoCommit(false);

            // Debit the amount from the sender's account
            pstmt = conn.prepareStatement(debitSql);
            pstmt.setBigDecimal(1, amount);
            pstmt.setInt(2, fromAccountNo);
            pstmt.executeUpdate();

            // Credit the amount to the recipient's account
            pstmt = conn.prepareStatement(creditSql);
            pstmt.setBigDecimal(1, amount);
            pstmt.setInt(2, toAccountNo);
            pstmt.executeUpdate();

            // Commit the transaction
            conn.commit();
        } catch (SQLException e) {
            // Handle exceptions, for example, by rolling back the transaction
            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            // Close resources and set auto-commit to true
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.setAutoCommit(true); // Set auto-commit back to true
                    conn.close();
                }
            } catch (SQLException closeException) {
                closeException.printStackTrace();
            }
        }
    }

    public static void withdraw(int accountNo, BigDecimal amount) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = dataSource.getConnection();
            conn.setAutoCommit(false); // Start a transaction

            // Create a SQL query to update the account balance by withdrawing the specified amount
         // Create a SQL query to update the account balance by withdrawing the specified amount
            String sql = "UPDATE accounts SET amount = amount - ? WHERE accountno = ?";


            pstmt = conn.prepareStatement(sql);
            pstmt.setBigDecimal(1, amount);
            pstmt.setInt(2, accountNo);

            // Execute the update query
            pstmt.executeUpdate();

            // Commit the transaction
            conn.commit();
        } catch (SQLException e) {
            // Handle exceptions, for example, by rolling back the transaction
            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            // Close resources and set auto-commit to true
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.setAutoCommit(true); // Set auto-commit back to true
                    conn.close();
                }
            } catch (SQLException closeException) {
                closeException.printStackTrace();
            }
        }
    }

}
    	
	