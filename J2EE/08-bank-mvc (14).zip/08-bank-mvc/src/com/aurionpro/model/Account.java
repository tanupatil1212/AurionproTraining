package com.aurionpro.model;

import java.math.BigDecimal;

public class Account {
	
	 private int accountNo;
	    private String accountType;
	    private int userId;
	    private BigDecimal amount;

	    public Account() {
			super();
		}

		public Account(String accountType, int userId, BigDecimal amount) {
			super();
			this.accountType = accountType;
			this.userId = userId;
			this.amount = amount;
		}
		

		public Account(int accountNo, String accountType, BigDecimal amount) {
			super();
			this.accountNo = accountNo;
			this.accountType = accountType;
			this.amount = amount;
		}

		public Account(int accountNo, String accountType, int userId, BigDecimal amount) {
		    this.accountNo = accountNo;
		    this.accountType = accountType;
		    this.userId = userId;
		    this.amount = amount;
		}

	    public int getAccountNo() {
	        return accountNo;
	    }

	    public void setAccountNo(int accountNo) {
	        this.accountNo = accountNo;
	    }

	    public String getAccountType() {
	        return accountType;
	    }

	    public void setAccountType(String accountType) {
	        this.accountType = accountType;
	    }

	    public int getUserId() {
	        return userId;
	    }

	    public void setUserId(int userId) {
	        this.userId = userId;
	    }

	    public BigDecimal getAmount() {
	        return amount;
	    }

	    public void setAmount(BigDecimal amount) {
	        this.amount = amount;
	    }

		@Override
		public String toString() {
			return "Account [accountNo=" + accountNo + ", accountType=" + accountType + ", userId=" + userId
					+ ", amount=" + amount + "]";
		}
	    
	}