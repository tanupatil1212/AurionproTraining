package com.aurionpro.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.eclipse.jdt.internal.compiler.flow.FinallyFlowContext;

import com.aurionpro.model.Student;

public class StudentDbUtil {
	
	private DataSource dataSource;
	
	public StudentDbUtil(DataSource theDataSource) {
		dataSource = theDataSource;
	}
	
	public List<Student> getAllStudnts(){
	 List<Student> students = new ArrayList<>();
	try {
		Connection conn=null;
		Statement stmt=null;
		ResultSet result=null;
		
		conn=dataSource.getConnection();
		String sql="select * from students";
		stmt = conn.createStatement();
		result = stmt.executeQuery(sql);
		
		while(result.next()){
			int id = result.getInt("id");
			String firstname = result.getString("first_name");
			String lastname=result.getString("last_name");
			String email = result.getString("email");
			Student tempStudent = new Student(id,firstname,lastname,email);
			
			students.add(tempStudent);
		}
		return students;
	}catch (SQLException e) {
		e.printStackTrace();
	}
	return students;
	}
}
