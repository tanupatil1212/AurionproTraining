package com.aurionpro.model;

import java.math.BigDecimal;

import java.util.Date;

public class Transaction {

	private int transactionId;
	private int accountNo;
	private int transactionTypeId;
	private String transactionTime;
	private String description; // New field for transaction description
	private BigDecimal amount; // New field for transaction amount

	public Transaction(int transactionId, int accountNo, int transactionTypeId, String transactionTime,
			String description, BigDecimal amount) {
		super();
		this.transactionId = transactionId;
		this.accountNo = accountNo;
		this.transactionTypeId = transactionTypeId;
		this.transactionTime = transactionTime;
		this.description = description;
		this.amount = amount;
	}

	public Transaction(int accountNo, int transactionTypeId, String transactionTime, String description,
			BigDecimal amount) {
		super();
		this.accountNo = accountNo;
		this.transactionTypeId = transactionTypeId;
		this.transactionTime = transactionTime;
		this.description = description;
		this.amount = amount;
	}

	public Transaction() {
		super();
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public int getTransactionTypeId() {
		return transactionTypeId;
	}

	public void setTransactionTypeId(int transactionTypeId) {
		this.transactionTypeId = transactionTypeId;
	}

	public String getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", accountNo=" + accountNo + ", transactionTypeId="
				+ transactionTypeId + ", transactionTime=" + transactionTime + ", description=" + description
				+ ", amount=" + amount + "]";
	}

}
