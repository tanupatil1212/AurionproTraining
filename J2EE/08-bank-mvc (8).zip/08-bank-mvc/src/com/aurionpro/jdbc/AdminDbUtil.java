package com.aurionpro.jdbc;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.aurionpro.model.Transaction;
import com.aurionpro.model.User;

public class AdminDbUtil {
	
	private DataSource dataSource;

	public AdminDbUtil(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}
	
	public boolean isValidAdmin(String username, String password) {
	    Connection conn = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    boolean isValid = false;

	    try {
	        conn = dataSource.getConnection();
	        String sql = "SELECT id FROM admins WHERE username = ? AND password = ?";
	        pstmt = conn.prepareStatement(sql);
	        pstmt.setString(1, username);
	        pstmt.setString(2, password);
	        rs = pstmt.executeQuery();

	        isValid = rs.next();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        // Close database resources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	            if (pstmt != null) {
	                pstmt.close();
	            }
	            if (conn != null) {
	                conn.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return isValid;
	}

	public boolean isValidUser(String username, String password) {
	    Connection conn = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    boolean isValid = false;

	    try {
	        conn = dataSource.getConnection();
	        String sql = "SELECT user_id FROM users WHERE username = ? AND password = ?";

	        pstmt = conn.prepareStatement(sql);
	        pstmt.setString(1, username);
	        pstmt.setString(2, password);
	        rs = pstmt.executeQuery();

	        isValid = rs.next();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    
	    }

	    return isValid;
	}
	
	 public List<Transaction> getAdminTransactions(String adminUsername) {
	        List<Transaction> transactions = new ArrayList<>();
	        Connection conn = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;

	        try {
	            conn = dataSource.getConnection();
	            String sql = "SELECT t.trans_id, t.account_no, t.transaction_type_id, t.transaction_time, " +
	                    "t.description, t.amount FROM transactions t " +
	                    "JOIN accounts a ON t.account_no = a.accountno " +
	                    "JOIN users u ON a.userid = u.user_id " +
	                    "WHERE u.username = ?";

	            pstmt = conn.prepareStatement(sql);
	            pstmt.setString(1, adminUsername);
	            rs = pstmt.executeQuery();

	            while (rs.next()) {
	                int transactionId = rs.getInt("trans_id");
	                int accountNo = rs.getInt("account_no");
	                int transactionTypeId = rs.getInt("transaction_type_id");
	                String transactionTime = rs.getString("transaction_time");
	                String description = rs.getString("description");
	                BigDecimal amount = rs.getBigDecimal("amount");

	                Transaction transaction = new Transaction(transactionId, accountNo, transactionTypeId,
	                        transactionTime, description, amount);
	                transactions.add(transaction);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close database resources
	            // ...
	        }

	        return transactions;
	    }

	 public List<User> getUsers() {
		    List<User> users = new ArrayList<>();
		    Connection conn = null;
		    PreparedStatement pstmt = null;
		    ResultSet rs = null;

		    try {
		        conn = dataSource.getConnection();
		        String sql = "SELECT user_id, fname, lname, username, password FROM users";
		        pstmt = conn.prepareStatement(sql);
		        rs = pstmt.executeQuery();

		        while (rs.next()) {
		            int user_id = rs.getInt("user_id");
		            String fname = rs.getString("fname");
		            String lname = rs.getString("lname");
		            String username = rs.getString("username");
		            String password = rs.getString("password");

		            User user = new User(user_id, fname, lname, username, password); // Update the User constructor
		            users.add(user);
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    } finally {
		        // Close database resources...
		    }

		    return users;
		}

	 public boolean createUser(User user) {
		    Connection conn = null;
		    PreparedStatement pstmt = null;
		    boolean userCreated = false;

		    try {
		        conn = dataSource.getConnection();
		        String sql = "INSERT INTO users (fname, lname, username, password) VALUES (?, ?, ?, ?)";
		        pstmt = conn.prepareStatement(sql);
		        pstmt.setString(1, user.getFname());
		        pstmt.setString(2, user.getLname());
		        pstmt.setString(3, user.getUsername());
		        pstmt.setString(4, user.getPassword());

		        int rowsAffected = pstmt.executeUpdate();
		        if (rowsAffected > 0) {
		            userCreated = true;
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    } finally {
		        // Close database resources...
		    }

		    return userCreated;
		}

	 public boolean createAccount(int userid, String accountType, BigDecimal amount) {
	        Connection conn = null;
	        PreparedStatement pstmt = null;
	        boolean accountCreated = false;

	        try {
	            conn = dataSource.getConnection();
	            String sql = "INSERT INTO accounts (accounttype, userid, amount) VALUES (?, ?, ?)";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setString(1, accountType);
	            pstmt.setInt(2, userid);
	            pstmt.setBigDecimal(3, amount);

	            int rowsAffected = pstmt.executeUpdate();
	            if (rowsAffected > 0) {
	                accountCreated = true;
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close database resources...
	        }

	        return accountCreated;
	    }
	}
