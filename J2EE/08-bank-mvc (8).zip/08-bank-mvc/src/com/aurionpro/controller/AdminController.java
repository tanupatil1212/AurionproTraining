package com.aurionpro.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.aurionpro.jdbc.AdminDbUtil;
import com.aurionpro.model.Transaction;
import com.aurionpro.model.User;

/**
 * Servlet implementation class AdminController
 */
@WebServlet("/AdminController")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Resource(name = "jdbc/bank-source")
	private DataSource datasource;
	private AdminDbUtil DbUtil;
	
       
    @Override
	public void init() throws ServletException {
    	
		
		super.init();
		DbUtil = new AdminDbUtil(datasource);
	}
       
    
    public AdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String command = request.getParameter("action");
		if (command == null) {
			command = "home";
		}
		switch (command) {
		case "home":

			try {
				request.getRequestDispatcher("/home.jsp").forward(request, response);
			} catch (Exception e) {
				// TODO: handle exception
			}
			break;
		case "admin":

			try {
				ifAdmin(request, response);
			} catch (Exception e) {
				// TODO: handle exception
			}
			break;
		case "user":

			try {
				ifUser(request, response);
			} catch (Exception e) {
				// TODO: handle exception
			}
			break;
		case "adminDashboard":
            showAdminDashboard(request, response);
            break;	
		case "viewUsers":
		    viewUsers(request, response);
		    break; // Handle the "View Users" action
		case "createUser":
		    createUser(request, response);
		    break;
		case "logout":
		    // Handle the logout action
		    // Implement your logic to log the admin out
		    // Redirect to the home page or login page
		    request.getSession().invalidate(); // Invalidate the session
		    response.sendRedirect(request.getContextPath() + "/home.jsp");
		    break;
		case "createAccount":
		    createAccount(request, response);
		    break;

				
		default:
			request.getRequestDispatcher("/home.jsp").forward(request, response);
		}
		
	}
	
	
	private void createAccount(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String userIdParam = request.getParameter("user_id");
	    String accountType = request.getParameter("accountType");
	    String amountParam = request.getParameter("amount");

	    if (userIdParam == null || accountType == null || amountParam == null || userIdParam.isEmpty() || amountParam.isEmpty()) {
	        // Handle the case where any of the required parameters is missing
	        request.setAttribute("errorMessage", "Missing or empty parameter(s). Please fill in all required fields.");
	        request.getRequestDispatcher("CreateAccount.jsp").forward(request, response);
	        return;
	    }

	    try {
	        int userId = Integer.parseInt(userIdParam);
	        BigDecimal amount = new BigDecimal(amountParam);

	        // Call the method to create the account
	        boolean accountCreated = DbUtil.createAccount(userId, accountType, amount);

	        if (accountCreated) {
	            // Account created successfully
	            // Redirect to a success page
	            response.sendRedirect("success.jsp");
	        } else {
	            // Account creation failed
	            // Redirect back to the CreateAccount.jsp page
	            request.setAttribute("errorMessage", "Account creation failed. Please try again.");
	            request.getRequestDispatcher("CreateAccount.jsp").forward(request, response);
	        }
	    } catch (NumberFormatException e) {
	        // Handle the case where the user_id or amount cannot be parsed as integers
	        request.setAttribute("errorMessage", "Invalid input for user ID or amount. Please enter valid numbers.");
	        request.getRequestDispatcher("CreateAccount.jsp").forward(request, response);
	    } catch (Exception e) {
	        e.printStackTrace(); // Add proper logging here
	        request.setAttribute("errorMessage", "An error occurred. Please try again.");
	        request.getRequestDispatcher("CreateAccount.jsp").forward(request, response);
	    }
	}





	private void createUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String fname = request.getParameter("fname");
	    String lname = request.getParameter("lname");
	    String username = request.getParameter("username");
	    String password = request.getParameter("password");

	    // Create a new User object with the provided information
	    User newUser = new User(fname, lname, username, password); // Store the plain text password

	    // Call a method to save the user to the database using your `AdminDbUtil`
	    boolean userCreated = DbUtil.createUser(newUser);

	    if (userCreated) {
	        // User created successfully
	        // Fetch the list of users after creating the new user
	        List<User> users = DbUtil.getUsers();
	        
	        // Set the list of users as an attribute in the request
	        request.setAttribute("users", users);
	        
	        // Redirect to the success.jsp page
	        request.getRequestDispatcher("success.jsp").forward(request, response);
	    } else {
	        // User creation failed
	        // Redirect to an error page or do something else
	        response.sendRedirect("error.jsp");
	    }
	}
 void viewUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    // Retrieve the list of users from your database (You need to implement this method)
	    List<User> users = DbUtil.getUsers();

	    // Set the list of users as an attribute in the request
	    request.setAttribute("users", users);

	    // Forward the request to the "users.jsp" page
	    request.getRequestDispatcher("/users.jsp").forward(request, response);
	}

	
	 private void showAdminDashboard(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        String adminUsername = (String) request.getSession().getAttribute("username");
	        if (adminUsername != null) {
	            List<Transaction> adminTransactions = DbUtil.getAdminTransactions(adminUsername);
	            request.setAttribute("adminTransactions", adminTransactions);
	            request.getRequestDispatcher("/adminDashboard.jsp").forward(request, response);
	        } else {
	            // Admin not logged in, handle this scenario
	        }
	    }

	private void ifUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String userType = request.getParameter("userType");
	    String username = request.getParameter("username");
	    String password = request.getParameter("password");

	    try {
	        if ("user".equals(userType)) {
	            if (DbUtil.isValidUser(username, password)) {
	                // Valid user login
	                request.getSession().setAttribute("userType", "user");
	                response.sendRedirect(request.getContextPath() + "/user.jsp");
	            } else {
	                // Invalid user login
	                System.out.println("Invalid user login: " + username);
	                request.setAttribute("errorMessage", "Invalid user login. Please try again.");
	                request.getRequestDispatcher("/home.jsp").forward(request, response);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        // Handle the exception, e.g., log it or show an error message
	    }


	}



	private void ifAdmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String userType = request.getParameter("userType");
	    String username = request.getParameter("username");
	    String password = request.getParameter("password");

	    if ("admin".equals(userType) && DbUtil.isValidAdmin(username, password)) {
	        // Valid admin login
	        
	        request.getSession().setAttribute("userType", "admin");
	        response.sendRedirect(request.getContextPath() + "/admin.jsp");
	    } else {
	        // Invalid admin login, show an error message
	        request.setAttribute("errorMessage", "Invalid admin login. Please try again.");
	        request.getRequestDispatcher("/home.jsp").forward(request, response);
	    }
	}

		


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
