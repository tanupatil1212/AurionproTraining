package com.aurionpro.controller;

import java.io.IOException;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.annotation.Resources;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.aurionpro.jdbc.EmployeeDbUtil;
import com.aurionpro.model.Employee;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	@Resource(name = "jdbc/employee-source")
	private DataSource datasource;
	private EmployeeDbUtil DbUtil;
       
    @Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		DbUtil = new EmployeeDbUtil(datasource);

	}

	/**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String command=request.getParameter("action");
		if(command == null) {
			command="list";
		}
		switch(command) {
		case "list":
			
			try {
				listEmployee(request ,response);
			} catch (Exception e) {
				// TODO: handle exception
			}
			break;
		case "add":
			
			try {
				addEmployee(request ,response);
			} catch (Exception e) {
				// TODO: handle exception
			}
			break;
		default:
			listEmployee(request, response);	
		}
	}

	

	
	

	private void addEmployee(HttpServletRequest request, HttpServletResponse response) throws ParseException, IOException {
	    int emp_ID = Integer.parseInt(request.getParameter("Emplid"));
	    String first_name = request.getParameter("firstname");
	    String last_name = request.getParameter("lastname");
	    String email = request.getParameter("email");
	    String DOJ = request.getParameter("DoJ");
	    String birthDate = request.getParameter("DOB");
	    Date doj = null;
	    Date dob = null;

	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	    try {
	        if (DOJ != null && !DOJ.isEmpty()) {
	            doj = new Date(dateFormat.parse(DOJ).getTime());
	        }

	        if (birthDate != null && !birthDate.isEmpty()) {
	            dob = new Date(dateFormat.parse(birthDate).getTime());
	        }
	    } catch (java.text.ParseException e) {
	        e.printStackTrace();
	       
	    }

	    Employee emp = new Employee(emp_ID, first_name, last_name, email, doj, dob);
	    DbUtil.AddEmployesList(emp);
	    response.sendRedirect(request.getContextPath() + "/EmployeeController");
	}


	private void listEmployee(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Employee> employeelist = DbUtil.getAllEmployee();
		RequestDispatcher dispatcher = request.getRequestDispatcher("/list-employee.jsp");
		request.setAttribute("allEmp", employeelist);
		dispatcher.forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
