package com.aurionpro.jdbc;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import javax.sql.DataSource;

import com.aurionpro.model.Employee;

public class EmployeeDbUtil {
	private DataSource dataSource;

	

	public EmployeeDbUtil(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}



	public List<Employee> getAllEmployee() {
		List<Employee> employees =new ArrayList<>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet result = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "select * from Employee";
			stmt = conn.createStatement();
			result = stmt.executeQuery(sql);
			
		while(result.next()) {
			
			int id =result.getInt("id");
			int emp_ID =result.getInt("emp_ID");
			String first_name = result.getString("first_name");
			String last_name = result.getString("last_name");
			String email = result.getString("email");
			Date DOJ  = result.getDate("DOJ");
			Date birthDate  = result.getDate("birthDate");
			
			Employee tempEmployee = new Employee(id, emp_ID, first_name, last_name, email, DOJ, birthDate);

            employees.add(tempEmployee);
			
			
			
		}
			
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		return employees;
	}



	public void AddEmployesList(Employee emp) {
	    Connection conn = null;
	    PreparedStatement stmt = null;

	    try {
	        conn = dataSource.getConnection();
	        String sql = "INSERT INTO Employee (emp_ID, first_name, last_name, email, DOJ, birthDate) VALUES (?, ?, ?, ?, ?, ?)";
	        stmt = conn.prepareStatement(sql);

	        // Set the values for the placeholders in the SQL statement
	        stmt.setInt(1, emp.getEmp_ID());
	        stmt.setString(2, emp.getFirst_name());
	        stmt.setString(3, emp.getLast_name());
	        stmt.setString(4, emp.getEmail());
	        stmt.setDate(5, new java.sql.Date(emp.getDOJ().getTime()));
	        stmt.setDate(6, new java.sql.Date(emp.getBirthDate().getTime()));

	        // Execute the SQL statement
	        int rowsAffected = stmt.executeUpdate();

	        if (rowsAffected > 0) {
	            // Data inserted successfully
	            System.out.println("Employee added successfully.");
	        } else {
	            // Data insertion failed
	            System.err.println("Failed to add employee.");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        System.err.println("Error while adding employee: " + e.getMessage());
	    } finally {
	        // Close resources in a finally block
	        try {
	            if (stmt != null) {
	                stmt.close();
	            }
	            if (conn != null) {
	                conn.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}


}
