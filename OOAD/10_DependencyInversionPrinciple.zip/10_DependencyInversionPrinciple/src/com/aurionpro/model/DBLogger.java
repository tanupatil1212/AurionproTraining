package com.aurionpro.model;

public class DBLogger {
    public void log(String err) {
        System.out.println("Logged to database: " + err);
    }
}
