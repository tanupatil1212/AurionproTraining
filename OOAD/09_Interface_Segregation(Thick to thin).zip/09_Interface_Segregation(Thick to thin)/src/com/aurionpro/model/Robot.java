package com.aurionpro.model;

public class Robot implements IWorkable {
    // Similarly, you don't need to provide any implementation here.
}
