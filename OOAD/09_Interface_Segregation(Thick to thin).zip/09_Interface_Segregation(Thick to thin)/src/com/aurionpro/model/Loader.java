package com.aurionpro.model;

public class Loader implements IWorker {
    // You don't need to provide any implementation here,
    // as the methods are already defined in the interfaces.
}
