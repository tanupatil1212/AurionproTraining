package com.aurionpro.model;

public interface IWorker extends IWorkable, ILunchInterval {
    // You don't need to provide any additional methods here.
}
