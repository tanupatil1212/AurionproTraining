package com.aurionpro.model;

public class Labour  implements IWorker {

}
