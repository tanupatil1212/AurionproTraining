package com.aurionpro.model;

public class Robot  implements IWorker{

}
