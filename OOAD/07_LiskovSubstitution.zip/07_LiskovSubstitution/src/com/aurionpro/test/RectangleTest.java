package com.aurionpro.test;

import com.aurionpro.model.Rectangle;

public class RectangleTest {

    private int curr; // Declare curr variable here

    public static void main(String[] args) {
        RectangleTest test = new RectangleTest(); // Create an instance of RectangleTest
        test.runTest(); // Call the method that uses curr variable
    }

    void runTest() {
        Rectangle rectangle = new Rectangle(10, 20);
        System.out.println(isRectangle(rectangle)); // Output: true or false
    }

    boolean isRectangle(Rectangle obj) {
        System.out.println(obj.getHeight()); // 10
        int prev = obj.getWidth(); // 20
        // Changing height
        obj.setHeight(100);
        curr = obj.getWidth(); // Assign value to curr
        return prev == curr;
    }
}
