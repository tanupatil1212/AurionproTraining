package com.aurionpro.model;

public class DiwaliInterest implements IFestivalInterest{

	public double getInterestRate() {
		// TODO Auto-generated method stub
		return 8.5;
	}

}
