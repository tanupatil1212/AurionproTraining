package com.aurionpro.model;

public class HoliInterest implements IFestivalInterest {

	public double getInterestRate() {
		// TODO Auto-generated method stub
		return 7.5;
	}

}
