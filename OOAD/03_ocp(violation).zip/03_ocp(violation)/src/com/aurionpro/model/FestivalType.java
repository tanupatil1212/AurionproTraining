package com.aurionpro.model;

public enum FestivalType {
	NEWYEAR,DIWALI,HOLI,OTHERS;

}
