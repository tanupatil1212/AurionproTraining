package com.aurionpro.model;

public interface IFestivalInterest {
	double getInterestRate();

}
