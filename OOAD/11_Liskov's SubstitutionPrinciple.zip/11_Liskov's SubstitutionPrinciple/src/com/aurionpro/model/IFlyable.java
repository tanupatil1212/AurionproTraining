package com.aurionpro.model;

public interface IFlyable {
    void fly();
}