package com.aurionpro.model;

public interface IBird {
    String getBodyColor();
}
