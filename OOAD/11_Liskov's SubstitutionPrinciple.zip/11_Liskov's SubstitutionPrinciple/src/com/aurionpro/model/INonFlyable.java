package com.aurionpro.model;


public interface INonFlyable {
    void walk();
}
