package com.aurionpro.model;

public class TechLead implements IRole {

	@Override
	public String description() {
	    return "Tech Lead role description";
	}

	@Override
	public String responsibilty() {
		return "Tech Lead responsibilities";
	}

}
