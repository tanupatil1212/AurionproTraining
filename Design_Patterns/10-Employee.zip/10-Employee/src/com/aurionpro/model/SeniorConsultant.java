package com.aurionpro.model;

public class SeniorConsultant implements IRole {

	@Override
	public String description() {
		 return "Senior Consultant role description";
	}

	@Override
	public String responsibilty() {
		return "Senior Consultant responsibilities";
	}

}
