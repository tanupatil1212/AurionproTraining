package com.aurionpro.model;

public interface IRole {
	
	public String description();
	
	public String responsibilty();
	

}
