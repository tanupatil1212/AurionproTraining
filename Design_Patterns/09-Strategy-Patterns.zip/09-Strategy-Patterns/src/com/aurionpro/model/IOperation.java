package com.aurionpro.model;

public interface IOperation {

	void doOperation(int a, int b);

}
