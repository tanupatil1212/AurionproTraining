package com.aurionpro.model;

public interface Internet {
	
	public void connectTo(String server);

}
