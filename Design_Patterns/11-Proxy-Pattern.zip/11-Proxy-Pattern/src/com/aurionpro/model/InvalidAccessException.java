package com.aurionpro.model;

public class InvalidAccessException extends Exception {
	
	public InvalidAccessException(String message) {
		super(message);
	}

}
