package com.aurionpro.model;

public class GoldenHat extends HotDecorator {

	public GoldenHat(IHat hat) {
		super(hat);
		
	}

}
