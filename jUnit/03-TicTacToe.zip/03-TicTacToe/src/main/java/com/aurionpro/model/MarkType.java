package com.aurionpro.model;

public enum MarkType {
	X,O,EMPTY;

}
