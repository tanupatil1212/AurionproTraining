package com.aurionpro.model;

public enum ResultType {
	
	WIN,LOSS,DRAW,PROGRESS;

}
